class EmailPasswordAuthenticationBackend implements IAuthenticationBackend { // COMO (implementacao)
    public boolean signIn(Object credentials) {
        System.out.println("Authenticating in Email/Password backend");

        return true;
    }
    public boolean signOut() {
        System.out.println("You signed out from Email/Password backend");

        return true;
    }
}
