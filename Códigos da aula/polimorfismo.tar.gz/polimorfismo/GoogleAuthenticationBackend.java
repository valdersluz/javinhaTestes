class GoogleAuthenticationBackend implements IAuthenticationBackend { // COMO (implementacao)
    public boolean signIn(Object credentials) {
        System.out.println("Authenticating in Google backend");

        return true;
    }
    public boolean signOut() {
        System.out.println("You signed out from Google backend");

        return true;
    }
}
