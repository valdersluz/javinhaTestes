interface IAuthenticationBackend { // O QUE (API ou interface) +
    public abstract boolean signIn(Object credentials);
    public abstract boolean signOut();
}
