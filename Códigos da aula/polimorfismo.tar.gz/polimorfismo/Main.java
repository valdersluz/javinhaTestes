class Main {
    public static void m1(IAuthenticationBackend backend) {
        backend.signIn("credentials"); // LIGACAO DINAMICA
    }
    public static void m2(IAuthenticationBackend backend) {
        backend.signIn("credentials");
    }
    public static void m3(IAuthenticationBackend backend) {
        backend.signIn("credentials");
    }
    public static void m4(IAuthenticationBackend backend) {
        backend.signIn("credentials");
    }
    public static void m5(IAuthenticationBackend backend) {
        backend.signIn("credentials");
    }
    public static void main(String[] args) {
        IAuthenticationBackend backend = new EmailPasswordAuthenticationBackend();
        m1(backend);
        backend = new GoogleAuthenticationBackend();
        m1(backend);
    }
}
