package br.edu.ifba.inf008.editorreflection;

import java.util.Scanner;
import java.util.Vector;
import java.util.Iterator;
import java.lang.reflect.Field;
import java.util.Collections;
import java.lang.reflect.Method;

/**
 * Hello world!
 */

class Person {
    private String name;
    private int id;

    public Person(String name, int id) { this.name = name; this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public int getId() { return id; }
}

class Student extends Person {
    public Student(String name, int id) { super(name, id); }
}

class Professor extends Person {
    private String department;

    public Professor(String name, int id, String department) { super(name, id); this.department = department; }
    public void setDepartment(String department) { this.department = department; }
    public String getDepartment() { return department; }
}

public class App {
    private static Vector<Field> getAllFields(Class clazz) {
        Vector<Field> fields = new Vector<Field>();
        while (clazz != null) {
            Field fieldArray[] = clazz.getDeclaredFields();
            Collections.addAll(fields, fieldArray);
            clazz = clazz.getSuperclass();
        }
        return fields;
    }
    private static Method findMethod(Class clazz, String methodName, Class<?>... parameterTypes) {
        Method method = null;
        while (clazz != null) {
            try {
                method = clazz.getDeclaredMethod(methodName, parameterTypes);
            } catch (Exception e) {}
            if (method != null)
                return method;
            clazz = clazz.getSuperclass();
        }
        return null;
    }
    public static void main(String[] args) throws Exception {
        Vector<Object> myObjects = new Vector<Object>();
        myObjects.add(new Student("JOAO", 123));
        myObjects.add(new Professor("JOSE", 456, "DACOMP"));

        int option;
        Scanner inputScanner = new Scanner(System.in);
        do {
            // Show all objects
            System.out.println("Your object options:\n0 - Exit");
            Iterator i = myObjects.iterator();
            int x = 0;
            while (i.hasNext()) {
                System.out.println(++x + " - Edit " + i.next().getClass().getSimpleName());
            }
            option = inputScanner.nextInt();
            if (option == 0) break;
            Object myObject = myObjects.get(option - 1);
            // Show all selected object's attributes
            int fieldOption;
            do {
                System.out.println("Your field options:\n0 - Exit");
                Class clazz = myObject.getClass();
                int z = 0;
                Vector<Field> fields = getAllFields(clazz);
                for (Field field : fields) {
                    System.out.println(++z + " - Edit " + field.getName());
                }
                fieldOption = inputScanner.nextInt();
                if (fieldOption == 0) break;
                Field myField = fields.get(fieldOption - 1);
                String myFieldName = myField.getName();
                String accessorName = "get" + myFieldName.substring(0, 1).toUpperCase() + myFieldName.substring(1);
                String mutatorName = "set" + myFieldName.substring(0, 1).toUpperCase() + myFieldName.substring(1);
                clazz = myObject.getClass();
                Method myAccessorMethod = findMethod(clazz, accessorName);
                if (myAccessorMethod != null) {
                    System.out.println(myAccessorMethod.invoke(myObject));
                }
                Method myMutatorMethod = findMethod(clazz, mutatorName, myField.getType());
                System.out.println(myField.getType() + ", myMutatorMethod: " + myMutatorMethod);

                // Instanciar um objeto cujo tipo é myField.getType()
                // Popular este objeto de alguma forma
                String teste = "TESTE";
                Object myMutatorParam = myField.getType().newInstance();
                System.out.println("myMutatorParam: " + myMutatorParam);
                System.out.println("teste: " + teste);

                myMutatorMethod.invoke(myObject, myMutatorParam);
            } while (true);
        } while (true);
    }
}
