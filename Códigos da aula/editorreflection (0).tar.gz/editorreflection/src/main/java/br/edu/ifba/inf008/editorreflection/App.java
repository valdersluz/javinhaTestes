package br.edu.ifba.inf008.editorreflection;

import java.util.Scanner;
import java.util.Vector;
import java.util.Iterator;
import java.lang.reflect.Field;

/**
 * Hello world!
 */

class Person {
    private String name;
    private int id;

    public void setName(String name) { this.name = name; }
    public void setId(int id) { this.id = id; }
}

class Student extends Person {
}

class Professor extends Person {
    private String department;

    public void setDepartment(String department) { this.department = department; }
}

public class App {
    public static void main(String[] args) {
        Vector<Object> myObjects = new Vector<Object>();
        myObjects.add(new Student());
        myObjects.add(new Professor());

        int option;
        Scanner inputScanner = new Scanner(System.in);
        do {
            // Show all objects
            System.out.println("Your options:\n0 - Exit");
            Iterator i = myObjects.iterator();
            int x = 0;
            while (i.hasNext()) {
                System.out.println(++x + " - Edit " + i.next().getClass().getSimpleName());
            }
            option = inputScanner.nextInt();
            Object myObject = myObjects.get(option - 1);
            // Show all selected object's attributes
            System.out.println("This object'a attributes:");
            Class clazz = myObject.getClass();
            int z = 0;
            while (clazz != null) {
                Field[] fields = clazz.getDeclaredFields();
                for (int y = 0; y < fields.length; ++y) {
                    System.out.println(z++ + " - Edit " + fields[y]);
                }
                clazz = clazz.getSuperclass();
            }
        } while (option != 0);
    }
}
