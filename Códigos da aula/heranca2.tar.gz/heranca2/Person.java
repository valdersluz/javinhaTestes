import java.time.LocalDate;

class Person
{
    protected String name;
    private LocalDate birthDate;
    private int id;
    private String address;

    public Person(String name, int year, int month, int dayOfMonth, int id, String address) {
        this.name = name;
        this.birthDate = LocalDate.of(year, month, dayOfMonth);
        this.id = id;
        this.address = address;
    }

    public void notify(String message) {
        System.out.println("Notification to " + name + ": " + message);
    }

    public int getAge() {
        return LocalDate.now().getYear() - birthDate.getYear();
    }

    @Override
    public String toString() {
        return name + "," + birthDate + "," + id + "," + address;
    }
}
