class Main
{
    public static void main(String[] args) {
        Person p1 = new Person("Joao", 2015, 4, 10, 123, "Rua tal");
        p1.notify("Olá");
        System.out.println("Joao's age: " + p1.getAge());
        Student s1 = new Student("Maria", 2013, 4, 10, 123, "Rua tal", 456);
        s1.notify("Olá");
        System.out.println("Maria's age: " + s1.getAge());
        s1.enrollToCourse("POO");
        Professor pr1 = new Professor("Jose", 2013, 4, 10, 123, "Rua tal", "DACOMP");
        s1.notify("Olá");
        pr1.notify("Olá");

        System.out.println("Person [" + p1 + "]");
        System.out.println("Professor [" + pr1 + "]");
    }
}
