class Student extends Person
{
    private int enrollmentId;

    public Student(String name, int year, int month, int dayOfMonth, int id, String address, int enrollmentId) {
        super(name, year, month, dayOfMonth, id, address);
        this.enrollmentId = enrollmentId;
    }

    public void enrollToCourse(String course) {
        System.out.println("Enrolling " + name + " to course " + course);
    }
}
