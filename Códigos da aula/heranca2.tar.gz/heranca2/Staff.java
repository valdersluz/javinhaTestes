class Staff// extends Person
{
}
