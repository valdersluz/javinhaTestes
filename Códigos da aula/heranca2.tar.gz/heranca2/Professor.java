class Professor extends Person
{
    private String department;

    public Professor(String name, int year, int month, int dayOfMonth, int id, String address, String department) {
        super(name, year, month, dayOfMonth, id, address);
        this.department = department;
    }

    public void presentClass(String classSubject) {
        System.out.println("Professor " + name + " is presenting class " + classSubject);
    }

    @Override
    public void notify(String message) {
       System.out.println("Asking signature for " + name);
       super.notify(message);
    }

    @Override
    public String toString() {
        return super.toString() + "," + department;
    }
}
