package br.edu.ifba.inf008.labpackages;

import br.edu.ifba.inf008.labpackages.core.Player;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        Player player = new Player();
        System.out.println("Hello World!");
    }
}
