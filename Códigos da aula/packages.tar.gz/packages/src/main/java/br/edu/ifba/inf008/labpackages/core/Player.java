package br.edu.ifba.inf008.labpackages.core;

public class Player {
    private String name;
}
