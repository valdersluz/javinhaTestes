package br.edu.ifba.netflix;

class PlaybackManager {
    public static void startStream(StreamProtocol protocol) {
        protocol.play(); // LIGACAO DINAMICA
    }

    public static void main(String[] args) {
        startStream(new DASHStreamProtocol(new K4QualityDecoder()));
    }
}
