package br.edu.ifba.netflix;

class P720QualityDecoder implements IQualityDecoder
{
    public void decode() {
        System.out.println("Decoding 720p Standard Definition stream.");
    }
}
