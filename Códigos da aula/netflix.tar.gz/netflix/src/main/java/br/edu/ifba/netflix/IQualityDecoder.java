package br.edu.ifba.netflix;

interface IQualityDecoder
{
    public void decode();
}
