package br.edu.ifba.netflix;

class DASHStreamProtocol extends StreamProtocol
{
    public DASHStreamProtocol(IQualityDecoder decoder) {
        super(decoder);
    }

    public void play() {
        System.out.println("Initializing DASH (Dynamic Adaptive Streaming over HTTP) stack...");
        decode();
    }
}
