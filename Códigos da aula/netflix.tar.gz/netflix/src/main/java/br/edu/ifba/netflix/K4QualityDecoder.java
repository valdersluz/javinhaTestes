package br.edu.ifba.netflix;

class K4QualityDecoder implements IQualityDecoder
{
    public void decode() {
        System.out.println("Decoding 4K Ultra HD stream.");
    }
}
