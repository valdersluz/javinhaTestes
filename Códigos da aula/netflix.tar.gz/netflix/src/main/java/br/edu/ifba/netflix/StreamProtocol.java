package br.edu.ifba.netflix;

abstract class StreamProtocol
{
    private IQualityDecoder decoder;

    public StreamProtocol(IQualityDecoder decoder) {
        this.decoder = decoder;
    }

    protected void decode() {
        if (decoder != null) {
            decoder.decode(); // LIGACAO DINAMICAbr/edu/ifba/netflix
        }
    }

    public abstract void play();
}
