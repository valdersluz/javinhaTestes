package br.edu.ifba.netflix;

class HLSStreamProtocol extends StreamProtocol
{
    public HLSStreamProtocol(IQualityDecoder decoder) {
        super(decoder);
    }

    public void play() {
        System.out.println("Initializing HLS (HTTP Live Streaming) stack...");
        decode();
    }
}
