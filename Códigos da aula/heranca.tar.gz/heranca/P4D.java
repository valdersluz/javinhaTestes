class P4D extends P3D // Heranca de implementacao
{
    private float w;

    public P4D(float x, float y, float z, float w) {
        super(x, y, z);
        System.out.println("Construtor de P4D");
        this.w = w;
    }

    public void move(float dx, float dy, float dz, float dw) {
        // x += dx;
        // y += dy;
        // z += dz;
        // w += dw;
    }

    public void display() {
        // System.out.println("[" + x + ", " + y + ", " + z + "]");
    }
}
