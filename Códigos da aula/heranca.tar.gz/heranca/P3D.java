class P3D extends P2D // Heranca de implementacao
{
    private float z;

    public P3D(float x, float y, float z) {
        super(x, y);
        System.out.println("Construtor de P3D");
        this.z = z;
    }

    public void move(float dx, float dy, float dz) {
        move(dx, dy);
        z += dz;
    }

    @Override
    public void display() { // Sobreposicao de método
        System.out.println(z);
        super.display();
    }
}
