class Main
{
    public static void main(String[] args) {
        // P2D p1 = new P2D(1.0f, 2.0f);
        // p1.display();
        // p1.move(2.0f, -3.0f);
        // p1.display();
        P3D p2 = new P3D(1.0f, 2.0f, 3.0f);
        p2.move(1.0f, 2.0f, 3.0f);
        p2.display();

        // P4D p3 = new P4D(1.0f, 2.0f, 3.0f, 4.0f);
        // p3.move(1.0f, 1.0f, 1.0f, 1.0f);
        // p3.display();
    }
}
