class P2D
{
    private float x;
    private float y;

    public P2D(float x, float y) {
        System.out.println("Construtor de P2D");
        this.x = x;
        this.y = y;
    }

    public void move(float dx, float dy) {
        x += dx;
        y += dy;
    }

    public void display() {
        System.out.println("[" + x + ", " + y + "]");
    }
}
