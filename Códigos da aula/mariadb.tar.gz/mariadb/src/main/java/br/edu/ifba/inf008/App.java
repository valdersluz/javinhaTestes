package br.edu.ifba.inf008;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Properties;
import java.sql.SQLException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import br.edu.ifba.inf008.Book;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        // try {
        //     Connection connection = DriverManager.getConnection("jdbc:mariadb://localhost:3306/emile?user=emile&password=emile");
        //
        //     System.out.println("Connected to database");
        //
        //     String query = "SELECT a, name FROM book";
        //     Statement stmt = connectihibernate.dialecton.createStatement();
        //     ResultSet rs = stmt.executeQuery(query);
        //     while (rs.next()) {
        //         int a = rs.getInt("a");
        //         String name = rs.getString("name");
        //         System.out.println(a + ", " + name);
        //     }
        // } catch (SQLException e) {
        //     System.out.println("Database connection error: " + e.getMessage());
        // }

        Session session = HibernateUtil.getSessionFactory().openSession();

        try {
            Transaction transaction = session.beginTransaction();
            Book book = new Book();
            book.setName("Effective Java");
            Department d1 = new Department();
            Employee e1 = new Employee();
            d1.addEmployee(e1);
            Department d2 = new Department();
            Employee e2 = new Employee();
            d2.addEmployee(e2);
            session.save(book);
            session.save(d1);
            session.save(d2);
            session.save(e1);
            session.save(e2);
            transaction.commit();
            book = session.get(Book.class, 4);
            if (book != null) {
                System.out.println("Book details: " + book.getA() + ", " + book.getName());
            } else {
                System.out.println("Book not found!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
            HibernateUtil.getSessionFactory().close();
        }
    }
}
